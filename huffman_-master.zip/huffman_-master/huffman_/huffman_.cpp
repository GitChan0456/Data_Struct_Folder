﻿#include <stdio.h>
#include <stdlib.h>
#define alphabet 26

typedef struct Node {
	char alphabet_data;
	int frequency_data;
	struct Node* left;
	struct Node* right;
}TNode;

TNode* create_tree(char val, int fre_val, TNode* l, TNode* r)
{
	TNode* n = (TNode*)malloc(sizeof(TNode));

	n->alphabet_data = val;
	n->frequency_data = fre_val;
	n->left = l;
	n->right = r;
	return n;
}

TNode* huffman_tree(int freq[])		//3
{
	int i, j;
	TNode* n[alphabet];

	for (i = 0, j = 0; i < alphabet; i++)
	{
		if (freq[i] > 0)
		{
			n[j] = create_tree('a' + i, freq[i], NULL, NULL);
			j++;
		}
	}

	while (j > 1)
	{
		// 가장 작은 빈도수를 가진 두 노드를 찾습니다.
		int min1 = 0;
		int min2 = 1;

		// 남아 있는 노드들 중에서 두 개의 최소 빈도수를 가진 노드를 찾습니다.
		for (i = 2; i < j; i++)
		{
			if (n[i]->frequency_data < n[min1]->frequency_data)
			{
				min2 = min1;
				min1 = i;
			}
			else if (n[i]->frequency_data < n[min2]->frequency_data)
			{
				min2 = i;
			}
		}

		// 두 노드의 빈도수를 합한 새로운 내부 노드를 생성합니다.
		TNode* new_node = create_tree('\0', n[min1]->frequency_data + n[min2]->frequency_data, n[min1], n[min2]);

		// 배열에서 두 개의 최소 빈도수 노드를 제거합니다.
		n[min1] = new_node;
		n[min2] = n[j - 1];
		j--;
	}

	// 남아 있는 노드인 n[0]가 허프만 트리의 루트 노드입니다.
	TNode* root = n[0];
	return root;
}


void input_frequency(int freq[])	//1
{
	char c;

	FILE* fp;
	fp = fopen("input.txt", "r"); //input에서 읽어오기 
	if (fp == NULL)
		printf("파일열기 실패\n");

	while ((c = fgetc(fp)) != EOF) //빈도수 계산하기 
	{
		if (isalpha(c))		//알파벳일 경우 
		{
			c = tolower(c);
			freq[c - 'a']++;	//= 받아온 알파벳 ASCII값 - 97 즉, ( b(98) - a(97) = freq[1] = b)     
		}
	}
	printf("\n");
	fclose(fp);

}
void output_frequency(int freq[]) //2 
{
	int i;
	//int count=0;

	FILE* fp;
	fp = fopen("state.txt", "w");
	if (fp == NULL)
		printf("파일열기 실패\n");

	for (i = 0; i < alphabet; i++)
	{
		if (freq[i] > 0)
		{
			//printf("%c: %d\n", 'a' + i, freq[i]);
			fputc('a' + i, fp);
			fputc('\t', fp);
			fprintf(fp, "%d", freq[i]);
			fputc('\n', fp);
			//count++;
		}
	}
	//printf("사용된 알파벳: %d개\n",count);
	fclose(fp);
}

int main()
{
	int freq[alphabet] = { 0 };
	TNode* n;

	input_frequency(freq);			//input.txt에서 읽어와 알파벳의 빈도수 계산 
	output_frequency(freq); 		//state.txt에 사용된 알파벳과 빈도수 붙여넣기  
	n = huffman_tree(freq);			//트리를 만들고 허프만 압축 

}