#include <stdio.h>
#include "tree.h"

void test()
{
	Node* root;

	root = makeTree();
	printTree(root);

}