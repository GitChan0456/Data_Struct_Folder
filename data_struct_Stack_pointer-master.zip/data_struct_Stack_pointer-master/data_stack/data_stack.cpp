﻿#include <stdio.h>
#include <stdio.h>
#include <string.h>
#define MAX_STACK_SIZE 100
typedef struct Student {
    int id;
    char name[32];
    char dept[32];
} Student;
typedef Student Element;

Element data[MAX_STACK_SIZE];
int top;

typedef struct stack {
    Element data[MAX_STACK_SIZE];
}Stack;
//error시 멈춤
void error(char str[])
{
    printf("%s\n", str);
    exit(1);
}
//주요 스택 연산
void init_stack(Stack *s) {s->top = -1; }
int size(Stack* s) { return s-> top + 1; }
int is_empty(Stack *s) { return (s-> top == -1); }
int is_full(Stack* s) { return (s->top == MAX_STACK_SIZE - 1); }
void push(Stack *s,Element e)
{
    if (is_full(s))
        error("스택 포화 에러");
    s->data[s->++top] = e;
}
Element pop(Stack *s)
{
    if (is_empty(s))
        error("스택 공백 에러");
    return s->data[s->top--];
}
Element peek(Stack *s)
{
    if (is_empty())
        error("스택 공백 에러");
    return data[top];
}
void print_stack(Stack *s, char msg[]) {
    int i;
    printf("%s[%2d]= ", msg, size(&s));
    for (i = 0; i < size(&s) ); i++)
        printf("\n\t%-15d %-10s %-20s", 
            s.data[i].id, s.data[i].name, s.dat[i].dept);
    printf("\n");
}
//학생정보함수
Student get_student(int id, char name[], char dept[])
{
    Student s;
    s.id = 
}
{
    Student s;
    s.id = id;
    strcpy(s.name, name);
    strcpy(s.dept, dept);
    return s;
}

int main()
{
    Stack s;
    Element e;
    init_stack(&s);
    push(&s, get_student(202010754, "소예찬", "컴퓨터공학과");
    push(&s, get_student(202010754, "소예찬", "컴퓨터공학과");
    push(&s, get_student(202010754, "소예찬", "컴퓨터공학과");
    push(&s, get_student(202010754, "소예찬", "컴퓨터공학과");
    print_stack("친구 4명 추가");
    pop(&s);
    print_stack("친구 1명 삭제 후");
    e = peek(&s);

    return 0;
}